import { useState, useCallback, useMemo } from 'react';
import { Header } from '@/components/Header';
import { StockSelector } from '@/components/StockSelector';
import { StockInfo } from '@/components/StockInfo';
import { PriceChart } from '@/components/PriceChart';
import { PredictionPanel } from '@/components/PredictionPanel';
import { MetricsPanel } from '@/components/MetricsPanel';
import { AnalysisPanel } from '@/components/AnalysisPanel';
import { EmptyState } from '@/components/EmptyState';
import { useToast } from '@/hooks/use-toast';
import {
  type Sector,
  type Stock,
  type PredictionResult,
  generateHistoricalData,
  generatePrediction,
} from '@/data/stockData';

const Index = () => {
  const [selectedSector, setSelectedSector] = useState<Sector | null>(null);
  const [selectedStock, setSelectedStock] = useState<Stock | null>(null);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const historicalData = useMemo(() => {
    if (!selectedStock) return [];
    return generateHistoricalData(selectedStock, 365);
  }, [selectedStock]);

  const handleSectorChange = useCallback((sector: Sector) => {
    setSelectedSector(sector);
    setSelectedStock(null);
    setPrediction(null);
  }, []);

  const handleStockChange = useCallback((stock: Stock) => {
    setSelectedStock(stock);
    setPrediction(null);
  }, []);

  const handlePredict = useCallback(async () => {
    if (!selectedStock) return;
    
    setIsLoading(true);
    
    // Simulate API call to Python backend
    await new Promise((resolve) => setTimeout(resolve, 1500));
    
    const result = generatePrediction(selectedStock);
    setPrediction(result);
    setIsLoading(false);
    
    toast({
      title: 'Prediction Complete',
      description: `${selectedStock.symbol} analysis generated with ${result.confidence}% confidence.`,
    });
  }, [selectedStock, toast]);


  return (
    <div className="min-h-screen bg-background">
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl" />
      </div>
      
      <div className="relative">
        <Header />
        
        <main className="container max-w-7xl mx-auto px-4 py-6 space-y-6">
          <StockSelector
            selectedSector={selectedSector}
            selectedStock={selectedStock}
            onSectorChange={handleSectorChange}
            onStockChange={handleStockChange}
            onPredict={handlePredict}
            isLoading={isLoading}
          />
          
          {selectedStock ? (
            <div className="space-y-6">
              <StockInfo stock={selectedStock} />
              
              <div className="grid lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <PriceChart data={historicalData} prediction={prediction} />
                </div>
                
                {prediction ? (
                  <PredictionPanel prediction={prediction} />
                ) : (
                  <div className="glass-card rounded-2xl p-6 flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                        <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                      </div>
                      <p className="text-muted-foreground">
                        Click <span className="text-primary font-medium">Predict</span> to generate AI forecast
                      </p>
                    </div>
                  </div>
                )}
              </div>
              
              {prediction && <MetricsPanel prediction={prediction} />}
              
              <AnalysisPanel stock={selectedStock} historicalData={historicalData} />
            </div>
          ) : (
            <EmptyState />
          )}
        </main>
        
        {/* Footer */}
        <footer className="border-t border-white/5 mt-12">
          <div className="container max-w-7xl mx-auto px-4 py-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="pulse-dot" />
                <span>StockAI Predictor — LSTM Deep Learning Platform</span>
              </div>
              <div className="text-xs">
                Disclaimer: Predictions are for educational purposes only. Not financial advice.
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default Index;
