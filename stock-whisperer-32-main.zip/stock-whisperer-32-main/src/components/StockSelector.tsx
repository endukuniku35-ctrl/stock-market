import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Brain, Loader2 } from 'lucide-react';
import { sectors, stocksBySector, type Sector, type Stock } from '@/data/stockData';

interface StockSelectorProps {
  selectedSector: Sector | null;
  selectedStock: Stock | null;
  onSectorChange: (sector: Sector) => void;
  onStockChange: (stock: Stock) => void;
  onPredict: () => void;
  isLoading: boolean;
}

export function StockSelector({
  selectedSector,
  selectedStock,
  onSectorChange,
  onStockChange,
  onPredict,
  isLoading,
}: StockSelectorProps) {
  const availableStocks = selectedSector ? stocksBySector[selectedSector] : [];

  return (
    <div className="glass-card rounded-2xl p-6 animate-fade-in">
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-end">
        <div className="flex-1 w-full lg:w-auto">
          <label className="metric-label mb-2 block">Select Sector</label>
          <Select
            value={selectedSector || ''}
            onValueChange={(value) => onSectorChange(value as Sector)}
          >
            <SelectTrigger className="w-full h-12 bg-secondary/50 border-white/10 text-foreground">
              <SelectValue placeholder="Choose a sector..." />
            </SelectTrigger>
            <SelectContent className="bg-card border-white/10">
              {sectors.map((sector) => (
                <SelectItem key={sector} value={sector} className="text-foreground hover:bg-secondary">
                  {sector}
                  <span className="ml-2 text-xs text-muted-foreground">
                    ({stocksBySector[sector].length} stocks)
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex-1 w-full lg:w-auto">
          <label className="metric-label mb-2 block">Select Stock</label>
          <Select
            value={selectedStock?.symbol || ''}
            onValueChange={(symbol) => {
              const stock = availableStocks.find((s) => s.symbol === symbol);
              if (stock) onStockChange(stock);
            }}
            disabled={!selectedSector}
          >
            <SelectTrigger className="w-full h-12 bg-secondary/50 border-white/10 text-foreground disabled:opacity-50">
              <SelectValue placeholder={selectedSector ? "Choose a stock..." : "Select sector first"} />
            </SelectTrigger>
            <SelectContent className="bg-card border-white/10 max-h-[300px]">
              {availableStocks.map((stock) => (
                <SelectItem key={stock.symbol} value={stock.symbol} className="text-foreground hover:bg-secondary">
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-semibold">{stock.symbol}</span>
                    <span className="text-muted-foreground text-sm truncate max-w-[200px]">
                      {stock.name}
                    </span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button
          onClick={onPredict}
          disabled={!selectedStock || isLoading}
          className="w-full lg:w-auto h-12 px-6 bg-gradient-to-r from-primary to-cyan-500 hover:from-primary/90 hover:to-cyan-500/90 text-primary-foreground font-semibold shadow-lg glow-primary transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Brain className="w-4 h-4 mr-2" />
              Predict
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
