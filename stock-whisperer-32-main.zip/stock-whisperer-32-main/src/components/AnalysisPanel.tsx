import { Clock, Calendar, TrendingUp, History, Eye, Sparkles } from 'lucide-react';
import type { Stock, HistoricalDataPoint } from '@/data/stockData';

interface AnalysisPanelProps {
  stock: Stock;
  historicalData: HistoricalDataPoint[];
}

export function AnalysisPanel({ stock, historicalData }: AnalysisPanelProps) {
  // Calculate past analysis
  const yearAgoPrice = historicalData[0]?.close || stock.currentPrice * 0.8;
  const yearReturn = ((stock.currentPrice - yearAgoPrice) / yearAgoPrice) * 100;
  
  const avgPrice = historicalData.reduce((sum, d) => sum + d.close, 0) / historicalData.length;
  const volatility = Math.sqrt(
    historicalData.reduce((sum, d) => sum + Math.pow(d.close - avgPrice, 2), 0) / historicalData.length
  );
  const volatilityPercent = (volatility / avgPrice) * 100;

  // Calculate 52-week high/low
  const prices = historicalData.map(d => d.close);
  const high52w = Math.max(...prices);
  const low52w = Math.min(...prices);
  const fromHigh = ((stock.currentPrice - high52w) / high52w) * 100;

  const sections = [
    {
      title: 'Past Analysis',
      icon: History,
      color: 'text-orange-400',
      bgColor: 'bg-orange-400/10',
      items: [
        { label: '1Y Return', value: `${yearReturn >= 0 ? '+' : ''}${yearReturn.toFixed(1)}%`, highlight: yearReturn >= 0 },
        { label: 'Avg Price (1Y)', value: `$${avgPrice.toFixed(2)}` },
        { label: 'Volatility', value: `${volatilityPercent.toFixed(1)}%`, warning: volatilityPercent > 25 },
        { label: '52W High', value: `$${high52w.toFixed(2)}` },
        { label: '52W Low', value: `$${low52w.toFixed(2)}` },
      ],
    },
    {
      title: 'Present Analysis',
      icon: Eye,
      color: 'text-primary',
      bgColor: 'bg-primary/10',
      items: [
        { label: 'Current Price', value: `$${stock.currentPrice.toFixed(2)}` },
        { label: 'Today\'s Change', value: `${stock.change >= 0 ? '+' : ''}${stock.change.toFixed(2)}`, highlight: stock.change >= 0 },
        { label: 'From 52W High', value: `${fromHigh.toFixed(1)}%`, warning: fromHigh < -20 },
        { label: 'MA20', value: `$${stock.ma20.toFixed(2)}`, highlight: stock.currentPrice > stock.ma20 },
        { label: 'MA50', value: `$${stock.ma50.toFixed(2)}`, highlight: stock.currentPrice > stock.ma50 },
      ],
    },
    {
      title: 'Technical Signals',
      icon: Sparkles,
      color: 'text-purple-400',
      bgColor: 'bg-purple-400/10',
      items: [
        { label: 'Trend (MA20)', value: stock.currentPrice > stock.ma20 ? 'Above' : 'Below', highlight: stock.currentPrice > stock.ma20 },
        { label: 'Trend (MA50)', value: stock.currentPrice > stock.ma50 ? 'Above' : 'Below', highlight: stock.currentPrice > stock.ma50 },
        { label: 'Golden Cross', value: stock.ma20 > stock.ma50 ? 'Active' : 'Inactive', highlight: stock.ma20 > stock.ma50 },
        { label: 'Volume', value: stock.volume > 50000000 ? 'High' : stock.volume > 10000000 ? 'Normal' : 'Low' },
        { label: 'Momentum', value: stock.changePercent > 1 ? 'Strong' : stock.changePercent > 0 ? 'Positive' : 'Weak', highlight: stock.changePercent > 0 },
      ],
    },
  ];

  return (
    <div className="glass-card rounded-2xl p-6 animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-primary/20">
          <TrendingUp className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold">Comprehensive Analysis</h3>
          <p className="text-sm text-muted-foreground">Past, Present & Technical Indicators</p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {sections.map((section) => (
          <div key={section.title} className="rounded-xl bg-secondary/30 border border-white/5 overflow-hidden">
            <div className={`flex items-center gap-2 p-3 ${section.bgColor}`}>
              <section.icon className={`w-4 h-4 ${section.color}`} />
              <span className={`text-sm font-medium ${section.color}`}>{section.title}</span>
            </div>
            <div className="p-3 space-y-2">
              {section.items.map((item) => (
                <div key={item.label} className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{item.label}</span>
                  <span className={`font-mono ${
                    item.highlight ? 'text-bullish' : 
                    item.warning ? 'text-bearish' : 
                    'text-foreground'
                  }`}>
                    {item.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
        <Calendar className="w-3.5 h-3.5" />
        <span>Analysis based on {historicalData.length} trading days of historical data</span>
      </div>
    </div>
  );
}
