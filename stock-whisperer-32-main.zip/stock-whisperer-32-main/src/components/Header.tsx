import { TrendingUp, Activity, BarChart3 } from 'lucide-react';

export function Header() {
  return (
    <header className="glass-panel border-b border-white/5 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/20 blur-xl rounded-full" />
            <div className="relative flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-cyan-400 shadow-lg">
              <TrendingUp className="w-6 h-6 text-primary-foreground" />
            </div>
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-tight">
              <span className="text-gradient-primary">StockAI</span>
              <span className="text-foreground"> Predictor</span>
            </h1>
            <p className="text-xs text-muted-foreground">LSTM-Powered Analytics Platform</p>
          </div>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="hidden md:flex items-center gap-6">
            <div className="flex items-center gap-2 text-sm">
              <div className="pulse-dot" />
              <span className="text-muted-foreground">Live Market</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <div className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-primary" />
                <span>Model Active</span>
              </div>
              <div className="flex items-center gap-1.5">
                <BarChart3 className="w-3.5 h-3.5 text-bullish" />
                <span>500+ Stocks</span>
              </div>
            </div>
          </div>
          
          <div className="text-right">
            <div className="text-xs text-muted-foreground">Last Updated</div>
            <div className="text-sm font-mono text-foreground">
              {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
