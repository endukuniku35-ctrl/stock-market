import { useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Area,
  ComposedChart,
  ReferenceLine,
} from 'recharts';
import type { HistoricalDataPoint, PredictionResult } from '@/data/stockData';

interface PriceChartProps {
  data: HistoricalDataPoint[];
  prediction?: PredictionResult | null;
}

export function PriceChart({ data, prediction }: PriceChartProps) {
  const chartData = useMemo(() => {
    const recentData = data.slice(-90); // Last 90 days
    
    if (prediction) {
      // Add prediction point
      const lastDate = new Date(recentData[recentData.length - 1].date);
      lastDate.setDate(lastDate.getDate() + 1);
      
      return [
        ...recentData.map(d => ({
          ...d,
          predicted: null,
        })),
        {
          date: lastDate.toISOString().split('T')[0],
          close: null,
          predicted: prediction.predictedPrice,
          ma20: null,
          ma50: null,
        },
      ];
    }
    
    return recentData;
  }, [data, prediction]);

  const minPrice = useMemo(() => {
    const prices = chartData.filter(d => d.close).map(d => d.close as number);
    if (prediction) prices.push(prediction.predictedPrice);
    return Math.min(...prices) * 0.98;
  }, [chartData, prediction]);

  const maxPrice = useMemo(() => {
    const prices = chartData.filter(d => d.close).map(d => d.close as number);
    if (prediction) prices.push(prediction.predictedPrice);
    return Math.max(...prices) * 1.02;
  }, [chartData, prediction]);

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="glass-card p-3 rounded-lg border border-white/10 shadow-xl">
          <p className="text-xs text-muted-foreground mb-2">{formatDate(label)}</p>
          {data.close && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-primary" />
              <span className="text-xs text-muted-foreground">Close:</span>
              <span className="font-mono font-semibold">${data.close.toFixed(2)}</span>
            </div>
          )}
          {data.predicted && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-purple-500" />
              <span className="text-xs text-muted-foreground">Predicted:</span>
              <span className="font-mono font-semibold text-purple-400">${data.predicted.toFixed(2)}</span>
            </div>
          )}
          {data.ma20 && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-yellow-500" />
              <span className="text-xs text-muted-foreground">MA20:</span>
              <span className="font-mono text-sm">${data.ma20.toFixed(2)}</span>
            </div>
          )}
          {data.ma50 && (
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-orange-500" />
              <span className="text-xs text-muted-foreground">MA50:</span>
              <span className="font-mono text-sm">${data.ma50.toFixed(2)}</span>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="glass-card rounded-2xl p-6 animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold">Price History & Prediction</h3>
          <p className="text-sm text-muted-foreground">Last 90 days with MA indicators</p>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-0.5 bg-primary rounded" />
            <span className="text-muted-foreground">Price</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-0.5 bg-yellow-500 rounded" />
            <span className="text-muted-foreground">MA20</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-3 h-0.5 bg-orange-500 rounded" />
            <span className="text-muted-foreground">MA50</span>
          </div>
          {prediction && (
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 bg-purple-500 rounded-full" />
              <span className="text-muted-foreground">Prediction</span>
            </div>
          )}
        </div>
      </div>
      
      <div className="h-[350px] chart-container">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="hsl(189, 94%, 43%)" stopOpacity={0.3} />
                <stop offset="100%" stopColor="hsl(189, 94%, 43%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            
            <XAxis
              dataKey="date"
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 11 }}
              tickFormatter={formatDate}
              interval="preserveStartEnd"
            />
            <YAxis
              domain={[minPrice, maxPrice]}
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(215, 20%, 55%)', fontSize: 11 }}
              tickFormatter={(value) => `$${value.toFixed(0)}`}
              width={60}
            />
            <Tooltip content={<CustomTooltip />} />
            
            <Area
              type="monotone"
              dataKey="close"
              stroke="none"
              fill="url(#priceGradient)"
            />
            
            <Line
              type="monotone"
              dataKey="close"
              stroke="hsl(189, 94%, 43%)"
              strokeWidth={2}
              dot={false}
              connectNulls={false}
            />
            
            <Line
              type="monotone"
              dataKey="ma20"
              stroke="hsl(45, 93%, 47%)"
              strokeWidth={1.5}
              strokeDasharray="4 2"
              dot={false}
              connectNulls={false}
            />
            
            <Line
              type="monotone"
              dataKey="ma50"
              stroke="hsl(25, 95%, 53%)"
              strokeWidth={1.5}
              strokeDasharray="4 2"
              dot={false}
              connectNulls={false}
            />
            
            {prediction && (
              <Line
                type="monotone"
                dataKey="predicted"
                stroke="hsl(280, 100%, 70%)"
                strokeWidth={0}
                dot={{
                  r: 8,
                  fill: 'hsl(280, 100%, 70%)',
                  stroke: 'hsl(280, 100%, 85%)',
                  strokeWidth: 3,
                }}
                connectNulls={false}
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
