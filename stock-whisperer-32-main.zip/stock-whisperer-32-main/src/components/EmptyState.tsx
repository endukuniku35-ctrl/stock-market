import { BarChart3, TrendingUp, Brain, Zap } from 'lucide-react';

export function EmptyState() {
  const features = [
    { icon: TrendingUp, title: 'Real-Time Data', desc: 'Live market prices and volume' },
    { icon: Brain, title: 'LSTM Predictions', desc: 'Deep learning price forecasting' },
    { icon: BarChart3, title: 'Technical Analysis', desc: 'MA indicators & trends' },
    { icon: Zap, title: 'Accuracy Metrics', desc: 'RMSE, MAE, MAPE scores' },
  ];

  return (
    <div className="glass-card rounded-2xl p-8 lg:p-12 text-center animate-fade-in">
      <div className="relative inline-block mb-6">
        <div className="absolute inset-0 bg-primary/20 blur-2xl rounded-full" />
        <div className="relative flex items-center justify-center w-20 h-20 rounded-2xl bg-gradient-to-br from-primary to-cyan-400 shadow-lg">
          <TrendingUp className="w-10 h-10 text-primary-foreground" />
        </div>
      </div>
      
      <h2 className="text-2xl font-bold mb-2">
        <span className="text-gradient-primary">AI-Powered</span> Stock Analytics
      </h2>
      <p className="text-muted-foreground mb-8 max-w-md mx-auto">
        Select a sector and stock above to view comprehensive analysis, historical data, and LSTM-based price predictions.
      </p>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto">
        {features.map((feature) => (
          <div key={feature.title} className="stat-card text-center">
            <feature.icon className="w-6 h-6 text-primary mx-auto mb-2" />
            <div className="font-medium text-sm mb-1">{feature.title}</div>
            <div className="text-xs text-muted-foreground">{feature.desc}</div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 p-4 rounded-lg bg-secondary/30 border border-white/5 max-w-lg mx-auto">
        <p className="text-xs text-muted-foreground">
          <span className="text-primary font-medium">Pro Tip:</span> This platform supports 50+ stocks across 11 sectors.
          The LSTM model is trained on maximum historical data for accurate predictions.
        </p>
      </div>
    </div>
  );
}
