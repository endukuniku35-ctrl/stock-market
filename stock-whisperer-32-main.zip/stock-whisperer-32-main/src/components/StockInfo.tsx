import { ArrowUp, ArrowDown, TrendingUp, DollarSign, BarChart2, Activity } from 'lucide-react';
import type { Stock } from '@/data/stockData';

interface StockInfoProps {
  stock: Stock;
}

export function StockInfo({ stock }: StockInfoProps) {
  const isPositive = stock.change >= 0;
  
  return (
    <div className="glass-card rounded-2xl p-6 animate-fade-in">
      <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-3 mb-1">
            <h2 className="text-2xl font-bold font-mono">{stock.symbol}</h2>
            <span className={`prediction-badge ${isPositive ? 'bullish' : 'bearish'}`}>
              {isPositive ? <ArrowUp className="w-3.5 h-3.5" /> : <ArrowDown className="w-3.5 h-3.5" />}
              {isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%
            </span>
          </div>
          <p className="text-muted-foreground">{stock.name}</p>
          <p className="text-sm text-primary mt-1">{stock.sector}</p>
        </div>
        
        <div className="text-right">
          <div className="text-3xl font-bold font-mono">
            ${stock.currentPrice.toFixed(2)}
          </div>
          <div className={`text-sm font-mono ${isPositive ? 'text-bullish' : 'text-bearish'}`}>
            {isPositive ? '+' : ''}{stock.change.toFixed(2)} ({isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%)
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="stat-card">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-4 h-4 text-primary" />
            <span className="metric-label">Market Cap</span>
          </div>
          <div className="metric-value">{stock.marketCap}</div>
        </div>
        
        <div className="stat-card">
          <div className="flex items-center gap-2 mb-2">
            <BarChart2 className="w-4 h-4 text-primary" />
            <span className="metric-label">P/E Ratio</span>
          </div>
          <div className="metric-value">{stock.pe > 0 ? stock.pe.toFixed(1) : 'N/A'}</div>
        </div>
        
        <div className="stat-card">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-primary" />
            <span className="metric-label">Volume</span>
          </div>
          <div className="metric-value">{(stock.volume / 1000000).toFixed(1)}M</div>
        </div>
        
        <div className="stat-card">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="metric-label">Prev Close</span>
          </div>
          <div className="metric-value">${stock.previousClose.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}
