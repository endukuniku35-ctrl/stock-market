import { ArrowUpRight, ArrowDownRight, Target, Gauge, TrendingUp, AlertTriangle, CheckCircle2 } from 'lucide-react';
import type { PredictionResult } from '@/data/stockData';

interface PredictionPanelProps {
  prediction: PredictionResult;
}

export function PredictionPanel({ prediction }: PredictionPanelProps) {
  const isBullish = prediction.direction === 'UP';
  const priceChange = prediction.predictedPrice - prediction.currentPrice;
  const changePercent = (priceChange / prediction.currentPrice) * 100;

  return (
    <div className="glass-card rounded-2xl p-6 animate-scale-in">
      <div className="flex items-center gap-3 mb-6">
        <div className={`p-2 rounded-lg ${isBullish ? 'bg-bullish/20' : 'bg-bearish/20'}`}>
          <Target className={`w-5 h-5 ${isBullish ? 'text-bullish' : 'text-bearish'}`} />
        </div>
        <div>
          <h3 className="text-lg font-semibold">AI Prediction</h3>
          <p className="text-sm text-muted-foreground">LSTM Model Output</p>
        </div>
      </div>

      {/* Main Prediction */}
      <div className={`relative overflow-hidden rounded-xl p-6 mb-6 ${isBullish ? 'bg-bullish/10 border border-bullish/20' : 'bg-bearish/10 border border-bearish/20'}`}>
        <div className="absolute top-0 right-0 w-32 h-32 opacity-10">
          {isBullish ? (
            <ArrowUpRight className="w-full h-full text-bullish" />
          ) : (
            <ArrowDownRight className="w-full h-full text-bearish" />
          )}
        </div>
        
        <div className="relative">
          <div className="flex items-center gap-2 mb-2">
            <span className={`prediction-badge ${isBullish ? 'bullish' : 'bearish'}`}>
              {isBullish ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              {prediction.direction}
            </span>
            <span className="text-sm text-muted-foreground">Next Day Forecast</span>
          </div>
          
          <div className="flex items-baseline gap-3 mb-2">
            <span className={`text-4xl font-bold font-mono ${isBullish ? 'text-bullish' : 'text-bearish'}`}>
              ${prediction.predictedPrice.toFixed(2)}
            </span>
            <span className={`text-lg font-mono ${isBullish ? 'text-bullish' : 'text-bearish'}`}>
              ({isBullish ? '+' : ''}{changePercent.toFixed(2)}%)
            </span>
          </div>
          
          <div className="text-sm text-muted-foreground">
            Current: <span className="font-mono">${prediction.currentPrice.toFixed(2)}</span>
            <span className="mx-2">→</span>
            Expected: <span className={`font-mono ${isBullish ? 'text-bullish' : 'text-bearish'}`}>
              {isBullish ? '+' : ''}{priceChange.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Confidence Meter */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Gauge className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium">Model Confidence</span>
          </div>
          <span className="font-mono font-semibold text-primary">{prediction.confidence}%</span>
        </div>
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-primary to-cyan-400 rounded-full transition-all duration-1000"
            style={{ width: `${prediction.confidence}%` }}
          />
        </div>
      </div>

      {/* Analysis Tags */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50">
          <TrendingUp className={`w-4 h-4 ${prediction.historicalTrend === 'Bullish' ? 'text-bullish' : prediction.historicalTrend === 'Bearish' ? 'text-bearish' : 'text-warning'}`} />
          <div>
            <div className="text-xs text-muted-foreground">Trend</div>
            <div className="text-sm font-medium">{prediction.historicalTrend}</div>
          </div>
        </div>
        
        <div className="flex items-center gap-2 p-3 rounded-lg bg-secondary/50">
          <AlertTriangle className={`w-4 h-4 ${prediction.volatility === 'High' ? 'text-bearish' : prediction.volatility === 'Medium' ? 'text-warning' : 'text-bullish'}`} />
          <div>
            <div className="text-xs text-muted-foreground">Volatility</div>
            <div className="text-sm font-medium">{prediction.volatility}</div>
          </div>
        </div>
      </div>

      {/* Recommendation */}
      <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
        <div className="flex items-start gap-3">
          <CheckCircle2 className="w-5 h-5 text-primary mt-0.5" />
          <div>
            <div className="text-sm font-medium mb-1">AI Recommendation</div>
            <p className="text-sm text-muted-foreground">{prediction.recommendation}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
