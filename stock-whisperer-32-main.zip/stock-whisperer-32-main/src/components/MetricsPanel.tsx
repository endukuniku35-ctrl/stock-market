import { BarChart3, Target, Percent, Info } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import type { PredictionResult } from '@/data/stockData';

interface MetricsPanelProps {
  prediction: PredictionResult;
}

export function MetricsPanel({ prediction }: MetricsPanelProps) {
  const metrics = [
    {
      name: 'RMSE',
      fullName: 'Root Mean Square Error',
      value: prediction.rmse,
      unit: '$',
      icon: BarChart3,
      description: 'Average prediction error magnitude. Lower is better.',
      quality: prediction.rmse < prediction.currentPrice * 0.015 ? 'good' : prediction.rmse < prediction.currentPrice * 0.025 ? 'moderate' : 'poor',
    },
    {
      name: 'MAE',
      fullName: 'Mean Absolute Error',
      value: prediction.mae,
      unit: '$',
      icon: Target,
      description: 'Average absolute difference between predicted and actual prices.',
      quality: prediction.mae < prediction.currentPrice * 0.012 ? 'good' : prediction.mae < prediction.currentPrice * 0.02 ? 'moderate' : 'poor',
    },
    {
      name: 'MAPE',
      fullName: 'Mean Absolute Percentage Error',
      value: prediction.mape,
      unit: '%',
      icon: Percent,
      description: 'Percentage-based accuracy measure. Under 3% is excellent.',
      quality: prediction.mape < 2 ? 'good' : prediction.mape < 4 ? 'moderate' : 'poor',
    },
  ];

  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'good':
        return 'text-bullish';
      case 'moderate':
        return 'text-warning';
      case 'poor':
        return 'text-bearish';
      default:
        return 'text-muted-foreground';
    }
  };

  const getQualityBg = (quality: string) => {
    switch (quality) {
      case 'good':
        return 'bg-bullish/10 border-bullish/20';
      case 'moderate':
        return 'bg-warning/10 border-warning/20';
      case 'poor':
        return 'bg-bearish/10 border-bearish/20';
      default:
        return 'bg-secondary/50 border-white/10';
    }
  };

  return (
    <div className="glass-card rounded-2xl p-6 animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 rounded-lg bg-primary/20">
          <BarChart3 className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold">Model Accuracy</h3>
          <p className="text-sm text-muted-foreground">Performance Metrics</p>
        </div>
      </div>

      <div className="space-y-4">
        {metrics.map((metric) => (
          <div
            key={metric.name}
            className={`p-4 rounded-xl border transition-all duration-300 hover:scale-[1.02] ${getQualityBg(metric.quality)}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <metric.icon className={`w-5 h-5 ${getQualityColor(metric.quality)}`} />
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold">{metric.name}</span>
                    <Tooltip>
                      <TooltipTrigger>
                        <Info className="w-3.5 h-3.5 text-muted-foreground" />
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p className="font-medium mb-1">{metric.fullName}</p>
                        <p className="text-xs text-muted-foreground">{metric.description}</p>
                      </TooltipContent>
                    </Tooltip>
                  </div>
                  <p className="text-xs text-muted-foreground">{metric.fullName}</p>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-2xl font-bold font-mono ${getQualityColor(metric.quality)}`}>
                  {metric.unit === '$' ? '$' : ''}{metric.value.toFixed(2)}{metric.unit === '%' ? '%' : ''}
                </div>
                <div className="text-xs text-muted-foreground capitalize">{metric.quality}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 rounded-lg bg-secondary/30 border border-white/5">
        <p className="text-xs text-muted-foreground leading-relaxed">
          <span className="font-medium text-foreground">Note:</span> These metrics are calculated based on historical test data.
          Lower error values indicate better model performance. The LSTM model is trained on the last 2 years of data using 60-day lookback windows.
        </p>
      </div>
    </div>
  );
}
