// Simulated stock data organized by sector
// In production, this would come from Yahoo Finance API via your Python backend

export interface Stock {
  symbol: string;
  name: string;
  sector: string;
  currentPrice: number;
  previousClose: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap: string;
  pe: number;
  ma20: number;
  ma50: number;
}

export interface PredictionResult {
  symbol: string;
  currentPrice: number;
  predictedPrice: number;
  direction: 'UP' | 'DOWN';
  confidence: number;
  rmse: number;
  mae: number;
  mape: number;
  historicalTrend: 'Bullish' | 'Bearish' | 'Neutral';
  volatility: 'Low' | 'Medium' | 'High';
  recommendation: string;
}

export interface HistoricalDataPoint {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ma20?: number;
  ma50?: number;
}

export const sectors = [
  'Technology',
  'Healthcare',
  'Financial Services',
  'Consumer Cyclical',
  'Communication Services',
  'Industrials',
  'Consumer Defensive',
  'Energy',
  'Utilities',
  'Real Estate',
  'Basic Materials',
] as const;

export type Sector = typeof sectors[number];

export const stocksBySector: Record<Sector, Stock[]> = {
  'Technology': [
    { symbol: 'AAPL', name: 'Apple Inc.', sector: 'Technology', currentPrice: 178.72, previousClose: 176.55, change: 2.17, changePercent: 1.23, volume: 58234100, marketCap: '2.79T', pe: 28.5, ma20: 175.30, ma50: 172.80 },
    { symbol: 'MSFT', name: 'Microsoft Corporation', sector: 'Technology', currentPrice: 378.91, previousClose: 374.23, change: 4.68, changePercent: 1.25, volume: 21456700, marketCap: '2.81T', pe: 35.2, ma20: 370.50, ma50: 365.20 },
    { symbol: 'NVDA', name: 'NVIDIA Corporation', sector: 'Technology', currentPrice: 495.22, previousClose: 488.90, change: 6.32, changePercent: 1.29, volume: 45678900, marketCap: '1.22T', pe: 62.8, ma20: 480.10, ma50: 460.30 },
    { symbol: 'GOOGL', name: 'Alphabet Inc.', sector: 'Technology', currentPrice: 141.80, previousClose: 139.95, change: 1.85, changePercent: 1.32, volume: 28345600, marketCap: '1.78T', pe: 25.4, ma20: 138.20, ma50: 135.60 },
    { symbol: 'META', name: 'Meta Platforms Inc.', sector: 'Technology', currentPrice: 505.95, previousClose: 498.32, change: 7.63, changePercent: 1.53, volume: 15234500, marketCap: '1.29T', pe: 32.1, ma20: 490.80, ma50: 475.40 },
    { symbol: 'AVGO', name: 'Broadcom Inc.', sector: 'Technology', currentPrice: 1285.50, previousClose: 1270.25, change: 15.25, changePercent: 1.20, volume: 2345600, marketCap: '532B', pe: 45.3, ma20: 1260.00, ma50: 1220.00 },
    { symbol: 'AMD', name: 'Advanced Micro Devices', sector: 'Technology', currentPrice: 178.45, previousClose: 175.80, change: 2.65, changePercent: 1.51, volume: 52345800, marketCap: '288B', pe: 48.2, ma20: 172.30, ma50: 165.80 },
    { symbol: 'CRM', name: 'Salesforce Inc.', sector: 'Technology', currentPrice: 272.35, previousClose: 268.90, change: 3.45, changePercent: 1.28, volume: 5678900, marketCap: '264B', pe: 42.5, ma20: 265.50, ma50: 258.20 },
  ],
  'Healthcare': [
    { symbol: 'JNJ', name: 'Johnson & Johnson', sector: 'Healthcare', currentPrice: 156.78, previousClose: 155.90, change: 0.88, changePercent: 0.56, volume: 8234500, marketCap: '378B', pe: 15.2, ma20: 154.50, ma50: 152.30 },
    { symbol: 'UNH', name: 'UnitedHealth Group', sector: 'Healthcare', currentPrice: 528.45, previousClose: 522.30, change: 6.15, changePercent: 1.18, volume: 3456700, marketCap: '489B', pe: 22.8, ma20: 518.20, ma50: 510.60 },
    { symbol: 'PFE', name: 'Pfizer Inc.', sector: 'Healthcare', currentPrice: 28.92, previousClose: 28.45, change: 0.47, changePercent: 1.65, volume: 45678900, marketCap: '163B', pe: 12.4, ma20: 27.80, ma50: 26.90 },
    { symbol: 'ABBV', name: 'AbbVie Inc.', sector: 'Healthcare', currentPrice: 154.67, previousClose: 152.80, change: 1.87, changePercent: 1.22, volume: 6789000, marketCap: '273B', pe: 18.6, ma20: 150.40, ma50: 147.20 },
    { symbol: 'LLY', name: 'Eli Lilly and Company', sector: 'Healthcare', currentPrice: 752.30, previousClose: 742.85, change: 9.45, changePercent: 1.27, volume: 2890000, marketCap: '715B', pe: 85.4, ma20: 735.60, ma50: 710.20 },
    { symbol: 'MRK', name: 'Merck & Co., Inc.', sector: 'Healthcare', currentPrice: 118.45, previousClose: 117.20, change: 1.25, changePercent: 1.07, volume: 9234500, marketCap: '300B', pe: 16.8, ma20: 115.80, ma50: 112.40 },
  ],
  'Financial Services': [
    { symbol: 'JPM', name: 'JPMorgan Chase & Co.', sector: 'Financial Services', currentPrice: 195.67, previousClose: 193.45, change: 2.22, changePercent: 1.15, volume: 9234500, marketCap: '564B', pe: 11.2, ma20: 191.30, ma50: 186.80 },
    { symbol: 'BAC', name: 'Bank of America Corp', sector: 'Financial Services', currentPrice: 34.28, previousClose: 33.85, change: 0.43, changePercent: 1.27, volume: 42345600, marketCap: '272B', pe: 10.5, ma20: 33.10, ma50: 31.80 },
    { symbol: 'V', name: 'Visa Inc.', sector: 'Financial Services', currentPrice: 279.85, previousClose: 276.50, change: 3.35, changePercent: 1.21, volume: 7890000, marketCap: '574B', pe: 29.8, ma20: 273.40, ma50: 268.20 },
    { symbol: 'MA', name: 'Mastercard Inc.', sector: 'Financial Services', currentPrice: 458.92, previousClose: 452.30, change: 6.62, changePercent: 1.46, volume: 3456700, marketCap: '427B', pe: 35.6, ma20: 448.50, ma50: 438.90 },
    { symbol: 'GS', name: 'Goldman Sachs Group', sector: 'Financial Services', currentPrice: 385.42, previousClose: 380.15, change: 5.27, changePercent: 1.39, volume: 2345600, marketCap: '125B', pe: 14.8, ma20: 375.80, ma50: 365.40 },
    { symbol: 'BRK.B', name: 'Berkshire Hathaway', sector: 'Financial Services', currentPrice: 362.78, previousClose: 359.45, change: 3.33, changePercent: 0.93, volume: 4567800, marketCap: '785B', pe: 8.9, ma20: 356.20, ma50: 348.60 },
  ],
  'Consumer Cyclical': [
    { symbol: 'AMZN', name: 'Amazon.com Inc.', sector: 'Consumer Cyclical', currentPrice: 178.25, previousClose: 175.80, change: 2.45, changePercent: 1.39, volume: 48567890, marketCap: '1.84T', pe: 52.3, ma20: 172.40, ma50: 168.20 },
    { symbol: 'TSLA', name: 'Tesla Inc.', sector: 'Consumer Cyclical', currentPrice: 248.50, previousClose: 242.80, change: 5.70, changePercent: 2.35, volume: 98765400, marketCap: '789B', pe: 68.5, ma20: 238.60, ma50: 225.40 },
    { symbol: 'HD', name: 'Home Depot Inc.', sector: 'Consumer Cyclical', currentPrice: 345.67, previousClose: 342.30, change: 3.37, changePercent: 0.98, volume: 4567800, marketCap: '343B', pe: 22.4, ma20: 338.50, ma50: 332.10 },
    { symbol: 'NKE', name: 'Nike Inc.', sector: 'Consumer Cyclical', currentPrice: 98.45, previousClose: 97.20, change: 1.25, changePercent: 1.29, volume: 8234500, marketCap: '148B', pe: 28.6, ma20: 95.80, ma50: 92.40 },
    { symbol: 'MCD', name: 'McDonald\'s Corporation', sector: 'Consumer Cyclical', currentPrice: 295.78, previousClose: 293.45, change: 2.33, changePercent: 0.79, volume: 3456700, marketCap: '212B', pe: 24.8, ma20: 290.20, ma50: 285.60 },
  ],
  'Communication Services': [
    { symbol: 'NFLX', name: 'Netflix Inc.', sector: 'Communication Services', currentPrice: 628.45, previousClose: 618.90, change: 9.55, changePercent: 1.54, volume: 5678900, marketCap: '272B', pe: 45.2, ma20: 610.30, ma50: 590.80 },
    { symbol: 'DIS', name: 'Walt Disney Company', sector: 'Communication Services', currentPrice: 112.35, previousClose: 110.80, change: 1.55, changePercent: 1.40, volume: 12345600, marketCap: '205B', pe: 72.4, ma20: 108.50, ma50: 104.20 },
    { symbol: 'CMCSA', name: 'Comcast Corporation', sector: 'Communication Services', currentPrice: 42.78, previousClose: 42.15, change: 0.63, changePercent: 1.49, volume: 18234500, marketCap: '168B', pe: 11.2, ma20: 41.30, ma50: 39.80 },
    { symbol: 'T', name: 'AT&T Inc.', sector: 'Communication Services', currentPrice: 17.85, previousClose: 17.62, change: 0.23, changePercent: 1.31, volume: 32456700, marketCap: '128B', pe: 8.5, ma20: 17.20, ma50: 16.80 },
  ],
  'Industrials': [
    { symbol: 'CAT', name: 'Caterpillar Inc.', sector: 'Industrials', currentPrice: 298.45, previousClose: 294.80, change: 3.65, changePercent: 1.24, volume: 3456700, marketCap: '148B', pe: 16.8, ma20: 290.30, ma50: 282.60 },
    { symbol: 'UPS', name: 'United Parcel Service', sector: 'Industrials', currentPrice: 142.78, previousClose: 140.90, change: 1.88, changePercent: 1.33, volume: 4567800, marketCap: '122B', pe: 18.4, ma20: 138.50, ma50: 134.20 },
    { symbol: 'BA', name: 'Boeing Company', sector: 'Industrials', currentPrice: 178.92, previousClose: 175.45, change: 3.47, changePercent: 1.98, volume: 8234500, marketCap: '108B', pe: -25.6, ma20: 172.30, ma50: 168.80 },
    { symbol: 'HON', name: 'Honeywell International', sector: 'Industrials', currentPrice: 205.34, previousClose: 203.10, change: 2.24, changePercent: 1.10, volume: 3890000, marketCap: '135B', pe: 22.5, ma20: 200.80, ma50: 196.40 },
    { symbol: 'GE', name: 'General Electric', sector: 'Industrials', currentPrice: 158.67, previousClose: 156.25, change: 2.42, changePercent: 1.55, volume: 6789000, marketCap: '172B', pe: 28.3, ma20: 153.40, ma50: 148.20 },
  ],
  'Consumer Defensive': [
    { symbol: 'PG', name: 'Procter & Gamble', sector: 'Consumer Defensive', currentPrice: 162.45, previousClose: 161.20, change: 1.25, changePercent: 0.78, volume: 6234500, marketCap: '382B', pe: 26.4, ma20: 159.80, ma50: 156.40 },
    { symbol: 'KO', name: 'Coca-Cola Company', sector: 'Consumer Defensive', currentPrice: 62.78, previousClose: 62.15, change: 0.63, changePercent: 1.01, volume: 14567800, marketCap: '271B', pe: 24.8, ma20: 61.30, ma50: 59.80 },
    { symbol: 'PEP', name: 'PepsiCo Inc.', sector: 'Consumer Defensive', currentPrice: 172.35, previousClose: 170.80, change: 1.55, changePercent: 0.91, volume: 5234500, marketCap: '237B', pe: 27.2, ma20: 169.40, ma50: 166.20 },
    { symbol: 'WMT', name: 'Walmart Inc.', sector: 'Consumer Defensive', currentPrice: 168.92, previousClose: 167.45, change: 1.47, changePercent: 0.88, volume: 8345600, marketCap: '455B', pe: 32.5, ma20: 165.80, ma50: 162.30 },
    { symbol: 'COST', name: 'Costco Wholesale', sector: 'Consumer Defensive', currentPrice: 745.28, previousClose: 738.90, change: 6.38, changePercent: 0.86, volume: 2456700, marketCap: '331B', pe: 48.6, ma20: 732.40, ma50: 718.60 },
  ],
  'Energy': [
    { symbol: 'XOM', name: 'Exxon Mobil Corporation', sector: 'Energy', currentPrice: 108.45, previousClose: 106.80, change: 1.65, changePercent: 1.54, volume: 15234500, marketCap: '432B', pe: 12.8, ma20: 104.60, ma50: 101.20 },
    { symbol: 'CVX', name: 'Chevron Corporation', sector: 'Energy', currentPrice: 152.78, previousClose: 150.45, change: 2.33, changePercent: 1.55, volume: 8345600, marketCap: '283B', pe: 11.4, ma20: 148.30, ma50: 144.80 },
    { symbol: 'COP', name: 'ConocoPhillips', sector: 'Energy', currentPrice: 118.34, previousClose: 116.20, change: 2.14, changePercent: 1.84, volume: 5678900, marketCap: '138B', pe: 10.2, ma20: 114.50, ma50: 110.80 },
    { symbol: 'SLB', name: 'Schlumberger Limited', sector: 'Energy', currentPrice: 52.67, previousClose: 51.45, change: 1.22, changePercent: 2.37, volume: 9234500, marketCap: '75B', pe: 15.6, ma20: 50.30, ma50: 48.60 },
  ],
  'Utilities': [
    { symbol: 'NEE', name: 'NextEra Energy', sector: 'Utilities', currentPrice: 72.45, previousClose: 71.80, change: 0.65, changePercent: 0.91, volume: 8234500, marketCap: '149B', pe: 22.4, ma20: 70.60, ma50: 68.40 },
    { symbol: 'DUK', name: 'Duke Energy Corp', sector: 'Utilities', currentPrice: 102.78, previousClose: 101.90, change: 0.88, changePercent: 0.86, volume: 3456700, marketCap: '79B', pe: 18.6, ma20: 100.40, ma50: 98.20 },
    { symbol: 'SO', name: 'Southern Company', sector: 'Utilities', currentPrice: 78.92, previousClose: 78.25, change: 0.67, changePercent: 0.86, volume: 5678900, marketCap: '86B', pe: 20.2, ma20: 77.10, ma50: 75.30 },
  ],
  'Real Estate': [
    { symbol: 'PLD', name: 'Prologis Inc.', sector: 'Real Estate', currentPrice: 128.45, previousClose: 126.80, change: 1.65, changePercent: 1.30, volume: 4567800, marketCap: '119B', pe: 42.5, ma20: 124.60, ma50: 120.80 },
    { symbol: 'AMT', name: 'American Tower Corp', sector: 'Real Estate', currentPrice: 215.78, previousClose: 213.45, change: 2.33, changePercent: 1.09, volume: 2345600, marketCap: '101B', pe: 48.2, ma20: 210.30, ma50: 205.60 },
    { symbol: 'EQIX', name: 'Equinix Inc.', sector: 'Real Estate', currentPrice: 825.34, previousClose: 818.90, change: 6.44, changePercent: 0.79, volume: 678900, marketCap: '78B', pe: 85.4, ma20: 812.50, ma50: 798.20 },
  ],
  'Basic Materials': [
    { symbol: 'LIN', name: 'Linde plc', sector: 'Basic Materials', currentPrice: 458.92, previousClose: 454.30, change: 4.62, changePercent: 1.02, volume: 2456700, marketCap: '222B', pe: 32.8, ma20: 450.40, ma50: 442.60 },
    { symbol: 'APD', name: 'Air Products & Chemicals', sector: 'Basic Materials', currentPrice: 285.67, previousClose: 282.45, change: 3.22, changePercent: 1.14, volume: 1234500, marketCap: '63B', pe: 26.4, ma20: 280.30, ma50: 274.80 },
    { symbol: 'FCX', name: 'Freeport-McMoRan', sector: 'Basic Materials', currentPrice: 42.35, previousClose: 41.20, change: 1.15, changePercent: 2.79, volume: 12345600, marketCap: '61B', pe: 22.5, ma20: 40.10, ma50: 38.40 },
    { symbol: 'NEM', name: 'Newmont Corporation', sector: 'Basic Materials', currentPrice: 38.92, previousClose: 38.15, change: 0.77, changePercent: 2.02, volume: 8567800, marketCap: '44B', pe: 18.6, ma20: 37.20, ma50: 35.80 },
  ],
};

// Generate historical data for charts
export function generateHistoricalData(stock: Stock, days: number = 365): HistoricalDataPoint[] {
  const data: HistoricalDataPoint[] = [];
  const basePrice = stock.currentPrice * 0.7; // Start from 70% of current price
  const volatility = 0.02; // 2% daily volatility
  
  let currentDate = new Date();
  currentDate.setDate(currentDate.getDate() - days);
  
  let price = basePrice;
  const trend = (stock.currentPrice - basePrice) / days; // Overall upward trend
  
  for (let i = 0; i < days; i++) {
    const dailyReturn = (Math.random() - 0.45) * volatility + (trend / basePrice);
    price = price * (1 + dailyReturn);
    
    const high = price * (1 + Math.random() * 0.02);
    const low = price * (1 - Math.random() * 0.02);
    const open = low + Math.random() * (high - low);
    const close = low + Math.random() * (high - low);
    
    data.push({
      date: currentDate.toISOString().split('T')[0],
      open: parseFloat(open.toFixed(2)),
      high: parseFloat(high.toFixed(2)),
      low: parseFloat(low.toFixed(2)),
      close: parseFloat(close.toFixed(2)),
      volume: Math.floor(stock.volume * (0.5 + Math.random())),
    });
    
    currentDate.setDate(currentDate.getDate() + 1);
  }
  
  // Calculate moving averages
  for (let i = 0; i < data.length; i++) {
    if (i >= 19) {
      const ma20Sum = data.slice(i - 19, i + 1).reduce((sum, d) => sum + d.close, 0);
      data[i].ma20 = parseFloat((ma20Sum / 20).toFixed(2));
    }
    if (i >= 49) {
      const ma50Sum = data.slice(i - 49, i + 1).reduce((sum, d) => sum + d.close, 0);
      data[i].ma50 = parseFloat((ma50Sum / 50).toFixed(2));
    }
  }
  
  return data;
}

// Simulate prediction result
export function generatePrediction(stock: Stock): PredictionResult {
  const priceChange = (Math.random() - 0.4) * stock.currentPrice * 0.05; // -2% to +3% prediction
  const predictedPrice = parseFloat((stock.currentPrice + priceChange).toFixed(2));
  const direction = predictedPrice > stock.currentPrice ? 'UP' : 'DOWN';
  
  // Calculate simulated accuracy metrics
  const rmse = parseFloat((stock.currentPrice * (0.01 + Math.random() * 0.02)).toFixed(2));
  const mae = parseFloat((rmse * 0.8).toFixed(2));
  const mape = parseFloat((1.5 + Math.random() * 2).toFixed(2));
  
  const volatilityLevel = stock.changePercent > 2 ? 'High' : stock.changePercent > 1 ? 'Medium' : 'Low';
  const trend = stock.currentPrice > stock.ma50 ? 'Bullish' : stock.currentPrice < stock.ma50 ? 'Bearish' : 'Neutral';
  
  let recommendation = '';
  if (direction === 'UP' && trend === 'Bullish') {
    recommendation = 'Strong Buy Signal - Positive momentum aligned with long-term trend';
  } else if (direction === 'UP') {
    recommendation = 'Moderate Buy - Short-term opportunity despite mixed signals';
  } else if (direction === 'DOWN' && trend === 'Bearish') {
    recommendation = 'Consider Reducing Position - Downward pressure continues';
  } else {
    recommendation = 'Hold Position - Mixed signals suggest caution';
  }
  
  return {
    symbol: stock.symbol,
    currentPrice: stock.currentPrice,
    predictedPrice,
    direction,
    confidence: parseFloat((75 + Math.random() * 20).toFixed(1)),
    rmse,
    mae,
    mape,
    historicalTrend: trend,
    volatility: volatilityLevel,
    recommendation,
  };
}
